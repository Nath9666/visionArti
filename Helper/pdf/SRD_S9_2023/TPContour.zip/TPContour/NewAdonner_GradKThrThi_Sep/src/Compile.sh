gcc -o ../bin/EdGradientKirsh4SepMasksThrThi EdGradientKirsh4SepMasksThrThi.c  EdLibGradientKirsh4SepMasks.c EdLibThreshold.c EdLibThinning.c EdLibEdgeUtilities.c EdUtilities.c
